package com.example.wxchatdemo.tools;

public interface IEditTextChangeListener {
    void textChange(boolean isHasContent);
}
